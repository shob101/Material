module.exports = (sequelize, Sequelize) => {
    const quiz = sequelize.define("quiz", {
      catid: {
        type: Sequelize.INTEGER,
        references:{
         model: 'categories', // <<< Note, its table's name, not object name
        key: 'catid' // <<< Note, its a column name

        } 
      },
      catname: {
        type: Sequelize.STRING
      },
      quizid:{
        type: Sequelize.INTEGER,
        primaryKey:true,
        autoIncrement:true

      },
      quizname:{
        type: Sequelize.STRING

      },
    }, {
      freezeTableName: true, // Model tableName will be the same as the model name
      timestamps: false,
      underscored: true
    });
  
    return quiz;
  };