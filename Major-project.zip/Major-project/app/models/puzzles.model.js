module.exports = (sequelize, Sequelize) => {
    const puzzles = sequelize.define("puzzles", {
   
      puzzle_id:{
        type: Sequelize.INTEGER,
        primaryKey:true,
        autoIncrement:true

      },
      puzzle_name:{
        type: Sequelize.STRING,
        unique: true

      },
      puzzle_question:{
        type: Sequelize.STRING

      },
      puzzle_answer:{
        type: Sequelize.STRING(30)
        
      },
    }, {
      freezeTableName: true, // Model tableName will be the same as the model name
      timestamps: false,
      underscored: true
    });
  
    return puzzles;
  };