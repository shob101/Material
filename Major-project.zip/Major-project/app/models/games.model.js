
module.exports = (sequelize, Sequelize) => {
    const games = sequelize.define("games", {
      game_id: {
        type:Sequelize.INTEGER, 
        primaryKey:true,
        autoIncrement:true
      },
      game_name: {
        type: Sequelize.STRING,
        allowNull: false
      },
    }, {
      freezeTableName: true, // Model tableName will be the same as the model name
      timestamps: false,
      underscored: true
    });
    return games;
  };