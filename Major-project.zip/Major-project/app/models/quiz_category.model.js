
module.exports = (sequelize, Sequelize) => {
    const quiz_category = sequelize.define("quiz_category", {
      cat_id: {
        type:Sequelize.INTEGER, 
        primaryKey:true,
        autoIncrement:true
      },
      cat_name: {
        type: Sequelize.STRING,
        allowNull: false
      },
    }, {
      freezeTableName: true, // Model tableName will be the same as the model name
      timestamps: false,
      underscored: true
    });
    return quiz_category;
  };