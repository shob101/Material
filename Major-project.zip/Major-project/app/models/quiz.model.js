module.exports = (sequelize, Sequelize) => {
    const quiz = sequelize.define("quiz", {
      
    //   catname: {
    //     type: Sequelize.STRING
    //   },
      quiz_id:{
        type: Sequelize.INTEGER,
        primaryKey:true,
        autoIncrement:true

      },
      quiz_name:{
        type: Sequelize.STRING

      },
      quiz_cat_id: {
        type: Sequelize.INTEGER,
        references:{
         model: 'quiz_category', // <<< Note, its table's name, not object name
        key: 'cat_id' // <<< Note, its a column name

        } 
      },
      is_timed:{
        type: Sequelize.BOOLEAN

      },
    }, {
      freezeTableName: true, // Model tableName will be the same as the model name
      timestamps: false,
      underscored: true
    });
  
    return quiz;
  };