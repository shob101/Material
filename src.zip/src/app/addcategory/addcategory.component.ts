import { Component, OnInit } from '@angular/core';
import { QuestionService } from '../question.service';

@Component({
  selector: 'app-addcategory',
  templateUrl: './addcategory.component.html',
  styleUrls: ['./addcategory.component.scss']
})
export class AddcategoryComponent implements OnInit {
  data= [];

  constructor(private categoryService: QuestionService) { }

  ngOnInit(): void {
    this.categoryService.get().subscribe((ret: any[])=>{
      console.log(ret);
      this.data = ret;
    })  
  }

}
