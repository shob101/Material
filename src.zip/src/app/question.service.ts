import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs';
import {category} from '../category'
const httpOptions={
  headers: new HttpHeaders({'Content-Type':'application/json'})
};

@Injectable({
  providedIn: 'root'
})
export class QuestionService {
  category:category;
  private categoryUrl='http://localhost:8080/api/quiz'

  constructor(private httpClient: HttpClient) { }
  get(): Observable<category[]> {
    return this.httpClient.get<category[]>(this.categoryUrl)
  }
}
