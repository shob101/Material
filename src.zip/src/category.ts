export class category {
    catid: number;
    catname:string;
    constructor(catid,catname)
{
    this.catid=catid;
    this.catname=catname;

}    }